import React from 'react';
import ReactDOM from 'react-dom';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import Table from '@mui/material/Table';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import TrendingUpOutlinedIcon from '@mui/icons-material/TrendingUpOutlined';

class Trend extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      rows: [],
      test: "test"
    };
  }

  componentDidMount() {
    fetch("http://localhost:3000/trend")
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            rows: result
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  }

  render() {
    const { error, isLoaded, items } = this.state;
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <>
    <Container>
    <Grid container>
      <TableContainer component={Paper} style={{background:"#132235", padding:"1rem"}}>
    <h3 style={{margin:"0rem 0rem 1rem 0rem", textAlign:"center", color:"#fff"}}><TrendingUpOutlinedIcon /> TREND</h3>
    <Table aria-label="simple table">
            <TableHead style={{background:"#182F4B",}}>
              <TableRow>
                <TableCell style={{color:"#fff", borderBottom:"#182F4B"}}>Pair</TableCell>
                <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>Trend</TableCell>
                <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>%24HR</TableCell>
                <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>Price</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {this.state.rows.map((row) => (
                <TableRow
                  key={row.pair}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  <TableCell component="th" scope="row" style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>
                    {row.pair}
                  </TableCell>
                  <TableCell style={{color:"#fff",borderBottom:" 1px solid #182F4B"}}>{row.trend}</TableCell>
                  <TableCell style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>{row.hour}</TableCell>
                  <TableCell style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>{row.price}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
    </Grid>
        </Container>
        </>
      );
    }
  }
}

export default Trend;
