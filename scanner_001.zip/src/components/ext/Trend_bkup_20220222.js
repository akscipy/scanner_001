import React from 'react'
import PropTypes from 'prop-types'

import { connect } from 'react-redux'
import { set_trend_panel_data } from '../../actions'
import { bindActionCreators } from 'redux'
import { SET_TREND_PANEL_DATA } from '../../constants'

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import TrendingUpOutlinedIcon from '@mui/icons-material/TrendingUpOutlined';

// function createData( pair, trend, hour, price) {
//   return { pair, trend, hour, price };
// }
//
// const rows = [
//   createData('XTZUSD', 12, 6.0, 24),
//   createData('ADAUSD', 1.234, 9.0, 37),
//   createData('ETHUSD', 2.912, 16.0, 24),
//   createData('LINKUSD', 305, 3.7, 67),
// ];

const Trend = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
    // decrement
  }
}) => {
  return (
    <div>
        <Container>
        <Grid container>
          <TableContainer component={Paper} style={{background:"#132235", padding:"1rem"}}>
        <h3 style={{margin:"0rem 0rem 1rem 0rem", textAlign:"center", color:"#fff"}}><TrendingUpOutlinedIcon /> TREND</h3>

      <p onClick={() => set_trend_panel_data('test')}>test</p>

        <Table aria-label="simple table">
                <TableHead style={{background:"#182F4B",}}>
                  <TableRow>
                    <TableCell style={{color:"#fff", borderBottom:"#182F4B"}}>Pair</TableCell>
                    <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>Trend</TableCell>
                    <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>%24HR</TableCell>
                    <TableCell style={{color:"#fff",borderBottom:"#182F4B"}}>Price</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {trendPanelData.map((row) => (
                    <TableRow
                      key={row.pair}
                      sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                      <TableCell component="th" scope="row" style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>
                        {row.pair}
                      </TableCell>
                      <TableCell style={{color:"#fff",borderBottom:" 1px solid #182F4B"}}>{row.trend}</TableCell>
                      <TableCell style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>{row.hour}</TableCell>
                      <TableCell style={{color:"#fff",borderBottom:"1px solid #182F4B"}}>{row.price}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
        </Grid>
            </Container>

    </div>
  )
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Trend)
