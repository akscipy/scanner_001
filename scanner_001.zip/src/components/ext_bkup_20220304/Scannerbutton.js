import * as React from 'react';
import Button from '@mui/material/Button';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import PermIdentityOutlinedIcon from '@mui/icons-material/PermIdentityOutlined';
import Stack from '@mui/material/Stack';
import { Container } from '@mui/material';

export default function Scannerbutton() {
  return (
      <Container style={{marginTop:"1rem"}}>
    <Stack direction="row" spacing={2}>
      <Button startIcon={<DashboardOutlinedIcon />} style={{background: "#132235", color:"#fff", padding: "0.5rem 2rem"}}>
        Standard
      </Button>
      <Button startIcon={<SettingsOutlinedIcon />} style={{background: "#132235", color:"#fff", padding: "0.5rem 2rem"}}>
       Customize
      </Button>
      <Button startIcon={<PermIdentityOutlinedIcon />} style={{background: "#132235", color:"#fff", padding: "0.5rem 2rem"}}>
        Profile
      </Button>
    </Stack>
    </Container>
    
  );
}