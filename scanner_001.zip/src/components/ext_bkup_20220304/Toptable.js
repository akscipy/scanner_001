import * as React from 'react';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
// import banner from './images/Bg.png';
import Trend from './Trend';
import Topcoin from './Topcoin';
import Signal from './Signals';

export default function Toptable() {
  return (
    <>
      <Container>
      <img src="/images/Bg.png" width="100%" />
      </Container>
      <Container>
        <Grid container>
          <Grid item lg={4}>
            <Topcoin />
          </Grid>
          <Grid item lg={4}>
            <Trend />
          </Grid>
          <Grid item lg={4}>
            <Signal />
          </Grid>
        </Grid>
      </Container>
      <Container>
        <img src="/images/Bg.png" width="100%" />
      </Container>
    </>
  );
}
