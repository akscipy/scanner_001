import React from 'react'
import { styled } from '@mui/material/styles';
import { Box, Paper, Grid, Drawer, Typography } from '@mui/material';
import { makeStyles } from '@mui/styles';

import { connect } from 'react-redux';
import { set_trend_panel_data } from '@/src/actions';
import { bindActionCreators } from 'redux';

import { SET_TREND_PANEL_DATA } from '@/src/constants';

import Navbar from '@/src/components/layout/Navbar';


const Index = ({
  trendPanelData,
  actions: {
    set_trend_panel_data,
  },
}) => {
  return (
    <div>
      <Navbar />
    </div>
  )
}

Index.getInitialProps = async ({ store }) => {
  await store.dispatch(set_trend_panel_data())
  return {}
}

export default connect(
  state => state,
  dispatch => ({ actions: bindActionCreators({ set_trend_panel_data }, dispatch) })
)(Index)
